const list54 = {
  "pubg": {   
    "PUBG1": {
    "nama": "Pubg Royale Pass Kode:1",
    "hargaid": 150000,
    "harga":"Rp150.000",
    },
        "PUBG2": {
    "nama": "Pubg Elite Pass Plus Kode:2",
    "hargaid": 250000,
    "harga":"Rp250.000",
    },
        "PUBG15": {
    "nama": "PUBG MOBILE 15 UC",
    "hargaid": 3500,
    "harga":"Rp3.500",
    },
        "PUBG26": {
    "nama": "PUBG MOBILE 26 UC",
    "hargaid": 5500,
    "harga":"Rp5.500",
    },
        "PUBG35": {
    "nama": "PUBG MOBILE 35 UC",
    "hargaid": 7500,
    "harga":"Rp7.500",
    },
        "PUBG50": {
    "nama": "PUBG MOBILE 50 UC",
    "hargaid": 9500,
    "harga":"Rp9.500",
    },         
     "PUBG70": {
    "nama": "PUBG MOBILE 70 UC",
    "hargaid": 14500,
    "harga":"Rp14.500",
    },          
     "PUBG100": {
    "nama": "PUBG MOBILE 100 UC",
    "hargaid": 17500,
    "harga":"Rp17.500",
    },          
    "PUBG122": {
    "nama": "PUBG MOBILE 122 UC",
    "hargaid": 22800,
    "harga":"Rp22.800",
    },      
    "PUBG150": {
    "nama": "PUBG MOBILE 150 UC",
    "hargaid": 26800,
    "harga":"Rp26.800",
    },          
    "PUBG186": {
    "nama": "PUBG MOBILE 186 UC",
    "hargaid": 33345,
    "harga":"Rp33.345",
    },
    "PUBG200": {
    "nama": "PUBG MOBILE 200 UC",
    "hargaid": 37560,
    "harga":"Rp37.560",
    },
    "PUBG250": {
    "nama": "PUBG MOBILE 250 UC",
    "hargaid": 45670,
    "harga":"Rp45.670",
    },
    "PUBG530": {
    "nama": "PUBG MOBILE 530 UC",
    "hargaid": 89680,
    "harga":"Rp89.680",
    },
    "PUBG750": {
    "nama": "PUBG MOBILE 750 UC",
    "hargaid": 127540,
    "harga":"Rp127.540",
    },
    "PUBG800": {
    "nama": "PUBG MOBILE 800 UC",
    "hargaid": 137620,
    "harga":"Rp137.620",
    },
    "PUBG1100": {
    "nama": "PUBG MOBILE 1100 UC",
    "hargaid": 177906,
    "harga":"Rp177.906",
    },
    "PUBG1250": {
    "nama": "PUBG MOBILE 1250 UC",
    "hargaid": 205456,
    "harga":"Rp205.456",
   },
},
};

module.exports = { list54 }