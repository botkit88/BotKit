const list56 = {
  "aov": {   
    "AOV7": {
    "nama": "AOV 7 Vouchers",
    "hargaid": 2500,
    "harga":"Rp2.500",
    },
        "AOV18": {
    "nama": "AOV 18 Vouchers",
    "hargaid": 6200,
    "harga":"Rp6.200",
    },
        "AOV40": {
    "nama": "AOV 40 Vouchers",
    "hargaid": 9600,
    "harga":"Rp9.600",
    },
        "AOV90": {
    "nama": "AOV 90 Vouchers",
    "hargaid": 19500,
    "harga":"Rp19.500",
    },
        "AOV230": {
    "nama": "AOV 230 Vouchers",
    "hargaid": 45600,
    "harga":"Rp45.600",
    },
        "AOV470": {
    "nama": "AOV 470 Vouchers",
    "hargaid": 91600,
    "harga":"Rp91.600",
    },         
     "AOV950": {
    "nama": "AOV 950 Vouchers",
    "hargaid": 185000,
    "harga":"Rp185.000",
    },          
     "AOV1430": {
    "nama": "AOV 1430 Vouchers",
    "hargaid": 265000,
    "harga":"Rp265.000",
    },          
},
};

module.exports = { list56 }