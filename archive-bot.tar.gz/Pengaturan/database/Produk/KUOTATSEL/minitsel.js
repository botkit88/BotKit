const list32 = {
  "minitsel": {   
    "ME1": {
    "nama": "Telkomsel 500 MB / 1 Hari (Kode:1)",
    "hargaid": 8000, 
    "harga":"Rp8.000",
    },       
    "ME2": {
    "nama":"Telkomsel 1 GB / 1 Hari (Kode:2)",
    "hargaid": 11000,
    "harga":"Rp11.000",
    },
    "ME3": {
    "nama":"Telkomsel 3 GB / 1 Hari (Kode:3)",
    "hargaid": 18000,
    "harga":"Rp18.000",
    },
    "ME4": {
    "nama":"Telkomsel 1 GB / 1 Hari (Kode:4)",
    "hargaid": 20000,
    "harga":"Rp20.000",
    },
    "ME5": {
    "nama":"Telkomsel 15 GB / 3 Hari (Kode:5)",
    "hargaid": 55000,
    "harga":"Rp55.000",
    },
    "ME6": {
    "nama":"Telkomsel 1,5 GB / 7 Hari (Kode:6)",
    "hargaid": 32000,
    "harga":"Rp32.000",
    },
    "ME7": {
    "nama":"Telkomsel  3 GB / 7 Hari (Kode:7)",
    "hargaid": 40000,
    "harga":"Rp40.000",
    },
    "ME8": {
    "nama":"Telkomsel  10 GB / 7 Hari (Kode:7)",
    "hargaid": 55000,
    "harga":"Rp55.000",
    },
    "ME9": {
    "nama":"Telkomsel  2 GB / 14 Hari (Kode:7)",
    "hargaid": 35000,
    "harga":"Rp35.000",
    },
},
};

module.exports = { list32 }

