const list36 = {
  "freedomcombo": {   
    "FRC1": {
    "nama": "Indosat Freedom Combo 4 GB / 30 Hari (Kode:1)",
    "hargaid": 30000, 
    "harga":"Rp30.000",
    },       
    "FRC2": {
    "nama":"Indosat Freedom Combo 14 GB / 30 Hari (Kode:2)",
    "hargaid": 60000,
    "harga":"Rp60.000",
    },
    "FRC3": {
    "nama":"Indosat Freedom Combo 20 GB / 30 Hari (Kode:3)",
    "hargaid": 75000,
    "harga":"Rp75.000",
    },
    "FRC4": {
    "nama":"Indosat Freedom Combo 30 GB / 30 Hari(Kode:4)",
    "hargaid": 90000,
    "harga":"Rp90.000",
    },
    "FRC5": {
    "nama":"Indosat Freedom Combo 50 GB / 30 Hari (Kode:5)",
    "hargaid": 13000,
    "harga":"Rp13.000",
    },
},
};

module.exports = { list36 }

