const list17 = {
  "volumesf": {   
    "VL5": {
    "nama": "Smartfren Berbasis Volume 5.000 (Kode:5)",
    "hargaid": 6200,
    "harga":"Rp6.200",
    },       
    "VL10": {
    "nama":"Smartfren Berbasis Volume 10.000 (Kode:10)",
    "hargaid": 11200,
    "harga":"Rp11.200",
    },
    "VL15": {
    "nama":"Smartfren Berbasis Volume 15.000 (Kode:15)",
    "hargaid": 16200,
    "harga":"Rp16.200",
    },
    "VL20": {
    "nama":"Smartfren Berbasis Volume 20.000 (Kode:20)",
    "hargaid": 21200,
    "harga":"Rp21.200",
    },
},
};

module.exports = { list17 }

