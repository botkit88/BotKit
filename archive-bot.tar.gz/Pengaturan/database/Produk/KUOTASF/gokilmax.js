const list18 = {
  "gokilmax": {   
    "GM15": {
    "nama": "Smartfren Gokil Max 15.000 (Kode:15)",
    "hargaid": 19000,
    "harga":"Rp19.000",
    },       
    "GM30": {
    "nama":"Smartfren Gokil Max 30.000 (Kode:30)",
    "hargaid": 32000,
    "harga":"Rp32.000",
    },
    "GM60": {
    "nama":"Smartfren Gokil Max 60.000 (Kode:60)",
    "hargaid": 62000,
    "harga":"Rp62.000",
    },
    "GM80": {
    "nama":"Smartfren Gokil Max 80.000 (Kode:80)",
    "hargaid": 82000,
    "harga":"Rp82.000",
    },
},
};

module.exports = { list18 }

