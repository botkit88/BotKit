const list14 = {
  "tri": {   
    "TRI5": {
    "nama": "Pulsa Three 5.000",
    "hargaid": 6130,
    "harga":"Rp6.130",
    },
    "TRI10":{
    "nama":"Pulsa Three 10.000",
   "hargaid": 10670,
   "harga":"Rp10.670",
   },
   "TRI15":{
   "nama":"Pulsa Three 15.000",
   "hargaid": 15670,
   "harga":"Rp15.670",
   },
   "TRI20":{
   "nama":"Pulsa Three 20.000",
   "hargaid": 20670,
   "harga":"Rp20.670",
   },
   "TRI25":{
   "nama":"Pulsa Three 25.000",
   "hargaid": 25670,
   "harga":"Rp25.670",
   },
   "TRI30":{
   "nama":"Pulsa Three 30.000",
   "hargaid": 30670,
   "harga":"Rp30.670",
  },
  "TRI40":{
  "nama":"Pulsa Three 40.000",
  "hargaid": 40670,
  "harga":"Rp40.670",
  },
  "TRI50":{
  "nama":"Pulsa Three 50.000",
  "hargaid": 50670,
  "harga":"Rp50.670",
  },
  "TRI60":{
  "nama":"Pulsa Three 60.000",
  "hargaid": 60670,
  "harga":"Rp60.670",
  },
  "TRI70":{
  "nama":"Pulsa Three 70.000",
  "hargaid": 70670,
  "harga":"Rp70.670",
  },
  "TRI80":{
  "nama":"Pulsa Three 80.000",
  "hargaid": 80670,
  "harga":"Rp80.670",
  },
  "TRI90":{
  "nama":"Pulsa Three 90.000",
  "hargaid": 90670,
  "harga":"Rp90.670",
  },
  "TRI100":{
  "nama":"Pulsa Three 100.000",
  "hargaid": 100670,
  "harga":"Rp100.670",
  },
  "TRI150":{
 "nama":"Pulsa Three 150.000",
  "hargaid": 150670,
  "harga":"Rp150.670",
  },
 },
};

module.exports = { list14 }

