const list9 = {
  "xl": {   
    "XL5": {
    "nama": "Pulsa Xl 5.000",
    "hargaid": 6500,
    "harga":"Rp6.500",
    },
        "XL10": {
    "nama": "Pulsa Xl 10.000 ",
    "hargaid": 11500,
    "harga":"Rp11.500",
    },
        "XL15": {
    "nama": "Pulsa Xl 15.000",
    "hargaid": 15890,
    "harga":"Rp15.890",
    },
        "XL20": {
    "nama": "Pulsa Xl 20.000",
    "hargaid": 20890,
    "harga":"Rp20.890",
    },
       "XL25": {
    "nama": "Pulsa Xl 25.000",
    "hargaid": 25890,
    "harga":"Rp25.890",
    },
    "XL30": {
    "nama": "Pulsa Xl 30.000",
    "hargaid": 30890,
    "harga":"Rp30.890",
    },   
        "XL50": {
    "nama": "Pulsa Xl 50.000",
    "hargaid": 50890,
    "harga":"Rp50890",
    },    
        "XL100": {
    "nama": "Pulsa Xl 100.000",
    "hargaid": 100890,
    "harga":"Rp100.890",
    },       
        "XL150": {
    "nama": "Pulsa Xl 150.000",
    "hargaid": 150890,
    "harga":"Rp150.890",
    },       
      "XL200": {
    "nama": "Pulsa Xl 200.000",
    "hargaid": 200890,
    "harga":"Rp200.890",
    },       
},
};

module.exports = { list9 }

