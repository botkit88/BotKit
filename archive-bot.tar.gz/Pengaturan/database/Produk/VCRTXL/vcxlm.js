const list43 = {
  "vcxlm": {   
    "VCXM1": {
    "nama": "Voucher XL Data Mini 1 GB / 7 Hari (Kode:1)",
    "hargaid": 13000, 
    "harga":"Rp13.000",
    },       
    "VCXM2": {
    "nama": "Voucher XL Data Mini 2 GB / 7 Hari (Kode:2)",
    "hargaid": 16000, 
    "harga":"Rp16.000",
    },       
    "VCXM3": {
    "nama": "Voucher XL Data Mini 3 GB / 7 Hari (Kode:3)",
    "hargaid": 23000, 
    "harga":"Rp23.000",
    },         
},
};

module.exports = { list43 }

