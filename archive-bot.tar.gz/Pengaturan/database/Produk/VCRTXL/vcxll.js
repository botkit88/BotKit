const list45 = {
  "vcxll": {   
    "VCXLL1": {
    "nama": "Voucher XL Combo Lite S (Kode:1)",
    "hargaid": 26000, 
    "harga":"Rp26.000",
    },       
    "VCXLL2": {
    "nama": "Voucher XL Combo Lite M (Kode:2)",
    "hargaid": 54000, 
    "harga":"Rp54.000",
    },   
    "VCXLL3": {
    "nama": "Voucher XL Combo Lite XL (Kode:3)",
    "hargaid": 89000, 
    "harga":"Rp89.000",
    },       
    "VCXLL4": {
    "nama": "Voucher XL Combo Lite XXL (Kode:4)",
    "hargaid": 112000, 
    "harga":"Rp112.000",
    },   
    "VCXLL5": {
    "nama": "Voucher XL Combo Lite M (Kode:5)",
    "hargaid": 130000, 
    "harga":"Rp130.000",
    },   
},
};

module.exports = { list45 }

