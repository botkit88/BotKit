const list29 = {
  "hapytri": {   
    "HY1": {
    "nama": "Tri Data Happy 1 GB / 1 Hari (Kode:1)",
    "hargaid": 5650, 
    "harga":"Rp5.650",
    },       
    "HY2": {
    "nama":"Tri Data Happy 1,5 GB / 1 Hari (Kode:2)",
    "hargaid": 6000,
    "harga":"Rp6.000",
    },
    "HY3": {
    "nama":"Tri Data Happy 2 GB / 1 Hari (Kode:3)",
    "hargaid": 7800,
    "harga":"Rp7.800",
    },
    "HY4": {
    "nama":"Tri Data Happy 2.5 GB / 1 Hari (Kode:4)",
    "hargaid": 8300,
    "harga":"Rp8.300",
    },
    "HY5": {
    "nama":"Tri Data Happy 5 GB / 1 Hari (Kode:5)",
    "hargaid": 10200,
    "harga":"Rp10.200",
    },
    "HY6": {
    "nama":"Tri Data Happy 3 GB / 2 Hari (Kode:6)",
    "hargaid": 11000,
    "harga":"Rp11.000",
    },
},
};

module.exports = { list29 }

