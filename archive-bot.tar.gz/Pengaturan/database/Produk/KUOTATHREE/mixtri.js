const list28 = {
  "mixtri": {   
    "XM1": {
    "nama": "Tri Mix Combo 2 GB + 20 Menit (Kode:1)",
    "hargaid": 37700, 
    "harga":"Rp37.700",
    },       
    "XM2": {
    "nama":"Tri Mix Combo 32 GB + 30 Menit (Kode:2)",
    "hargaid": 70500,
    "harga":"Rp70.500",
    },
    "XM3": {
    "nama":"Tri Mix Combo 38 GB + 30 Menit (Kode:3)",
    "hargaid": 97600,
    "harga":"Rp97.600",
    },
    "XM4": {
    "nama":"Tri Mix Kuota+ + 1,25GB (Kode:4)",
    "hargaid": 33000,
    "harga":"Rp33.000",
    },
    "XM5": {
    "nama":"Tri Mix Kuota+ + 2,5GB (Kode:5)",
    "hargaid": 52000,
    "harga":"Rp52.000",
    },
    "XM6": {
    "nama":"Tri Mix Small 2,7 GB 3 Hari (Kode:6)",
    "hargaid": 14000,
    "harga":"Rp14.000",
    },
},
};

module.exports = { list28 }

