const list27 = {
  "minitri": {   
    "MT1": {
    "nama": "Tri Data Mini 1 GB / 5 Hari (Kode:1)",
    "hargaid": 9500, 
    "harga":"Rp9.500",
    },       
    "MT2": {
    "nama":"Tri Data Mini 1,5 GB / 5 Hari (Kode:2)",
    "hargaid": 14800,
    "harga":"Rp14.800",
    },
    "MT3": {
    "nama":"Tri Data Mini 2 GB / 5 Hari (Kode:3)",
    "hargaid": 16600,
    "harga":"Rp16.600",
    },
    "MT4": {
    "nama":"Tri Data Mini 1,5 GB / 7 Hari (Kode:4)",
    "hargaid": 18660,
    "harga":"Rp18.660",
    },
    "MT5": {
    "nama":"Tri Data Mini 3 GB / 7 Hari (Kode:5)",
    "hargaid": 20000,
    "harga":"Rp20.000",
    },
    "MT6": {
    "nama":"Tri Data Mini 5 GB / 7 Hari (Kode:6)",
    "hargaid": 25000,
    "harga":"Rp25.000",
    },
},
};

module.exports = { list27 }

