const list25 = {
  "alwayson": {   
    "AO2": {
    "nama": "AlwaysOn 2 GB (Kode:2)",
    "hargaid": 15890, 
    "harga":"Rp15.890",
    },       
    "AO3": {
    "nama":"AlwaysOn 3 GB (Kode:3)",
    "hargaid": 19800,
    "harga":"Rp19.800",
    },
    "AO6": {
    "nama":"AlwaysOn 6 GB (Kode:6)",
    "hargaid": 27600,
    "harga":"Rp27.600",
    },
    "AO8": {
    "nama":"AlwaysOn 8 GB (Kode:8)",
    "hargaid": 38700,
    "harga":"Rp38.700",
    },
    "AO9": {
    "nama":"AlwaysOn 9 GB (Kode:9)",
    "hargaid": 39700,
    "harga":"Rp39.700",
    },
    "AO12": {
    "nama":"AlwaysOn 12 GB (Kode:12)",
    "hargaid": 52700,
    "harga":"Rp52.700",
    },
},
};

module.exports = { list25 }

