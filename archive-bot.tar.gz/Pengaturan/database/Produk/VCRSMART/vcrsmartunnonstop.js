const list51 = {
  "vcrsmartunnonstop": {   
    "VSMUNNON1": {
    "nama": "Voucher Smartfren Unlimited Nonstop 2 GB 10 Hari(Kode:1)",
    "hargaid": 43000, 
    "harga":"Rp43.000",
    },       
    "VSMUNNON2": {
    "nama": "Voucher Smartfren Unlimited Nonstop 3 GB 14 Hari (Kode:2)",
    "hargaid": 74000, 
    "harga":"Rp74.000",
    },   
    "VSMUNNON3": {
    "nama": "Voucher Smartfren Unlimited Nonstop 4 GB / 14 Hari (Kode:3)",
    "hargaid": 95000, 
    "harga":"Rp95.000",
    },       
},
};

module.exports = { list51 }