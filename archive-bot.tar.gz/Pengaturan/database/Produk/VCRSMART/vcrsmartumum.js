const list52 = {
  "vcrsmartumum": {   
    "VSMU1": {
    "nama": "Voucher Smartfren Data 2.5 GB / 7 Hari (Kode:1)",
    "hargaid": 43000, 
    "harga":"Rp43.000",
    },       
},
};

module.exports = { list52 }