const list44 = {
  "vcxlx": {   
    "VCXX1": {
    "nama": "Voucher XL Xtra Combo Special 8 GB / 30 Hari (Kode:1)",
    "hargaid": 25000, 
    "harga":"Rp25.000",
    },       
    "VCXX2": {
    "nama": "Voucher XL Xtra Combo Special 14 GB / 30 Hari (Kode:2)",
    "hargaid": 37000, 
    "harga":"Rp37.000",
    },       
},
};

module.exports = { list44 }

