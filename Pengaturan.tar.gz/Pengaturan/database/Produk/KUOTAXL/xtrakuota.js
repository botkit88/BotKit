const list24 = {
  "xtrakuota": {   
    "XY1": {
    "nama": "XL XTRA KUOTA 2 GB Facebook - 3 Hari (Kode:1)",
    "hargaid": 6500,
    "harga":"Rp6.500",
    },       
    "XY2": {
    "nama":"XL XTRA KUOTA 2 GB TikTok - 3 Hari (Kode:2)",
    "hargaid": 7000,
    "harga":"Rp7.000",
    },
    "XY3": {
    "nama":"XL XTRA KUOTA 2 GB Instagram - 3 Hari (Kode:3)",
    "hargaid": 7200,
    "harga":"Rp7.200",
    },
    "XY4": {
    "nama":"XL XTRA KUOTA 2 GB Youtube - 3 Hari (Kode:4)",
    "hargaid": 7300,
    "harga":"Rp7.300",
    },
    "XY5": {
    "nama":"XL XTRA KUOTA 3 GB Youtube - 7 Hari (Kode:5)",
    "hargaid": 11000,
    "harga":"Rp11.000",
    },
    "XY6": {
    "nama":"XL XTRA KUOTA 3 GB Instagram - 7 Hari (Kode:6)",
    "hargaid": 11100,
    "harga":"Rp11.100",
    },
    "XY7": {
    "nama":"XL XTRA KUOTA 3 GB TikTok - 7 Hari (Kode:7)",
    "hargaid": 11500,
    "harga":"Rp11.500",
    },
    "XY8": {
    "nama":"XL XTRA KUOTA 5 GB IFLIX - 30 Hari (Kode:8)",
    "hargaid": 13500,
    "harga":"Rp13.500",
    },
    "XY9": {
    "nama":"XL XTRA KUOTA 2 GB Joox - 30 Hari (Kode:9)",
    "hargaid": 14000,
    "harga":"Rp14.000",
    },
    "XY10": {
    "nama":"XL XTRA KUOTA 3 GB Facebook - 7 Hari (Kode:10)",
    "hargaid": 11500,
    "harga":"Rp11.500",
    },
},
};

module.exports = { list24 }

