const list22 = {
  "xtracomboflex": {   
    "FX1": {
    "nama": "XL Xtra Combo Flex S (Kode:1)",
    "hargaid": 16200,
    "harga":"Rp16.200",
    },       
    "FX2": {
    "nama":"XL Xtra Combo Flex S+ (Kode:2)",
    "hargaid": 27000,
    "harga":"Rp27.000",
    },
    "FX3": {
    "nama":"XL Xtra Combo Flex M (Kode:3)",
    "hargaid": 37000,
    "harga":"Rp37.000",
    },
    "FX4": {
    "nama":"XL Xtra Combo Flex Basic (Kode:4)",
    "hargaid": 45000,
    "harga":"Rp45.000",
    },
       "FX5": {
    "nama":"XL Xtra Combo Flex L (Kode:5)",
    "hargaid": 55000,
    "harga":"Rp55.000",
    },   
},
};

module.exports = { list22 }

