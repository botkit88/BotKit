const list6 = {
  "smartfren": {   
    "SMR5": {
    "nama": "Pulsa Smartfren 5.000",
    "hargaid": 5806,
    "harga":"Rp5.806",
    },
        "SMR10": {
    "nama": "Pulsa Smartfren 10.000 ",
    "hargaid": 10560,
    "harga":"Rp10.560",
    },
        "SMR15": {
    "nama": "Pulsa Smartfren 15.000",
    "hargaid": 15560,
    "harga":"Rp15.560",
    },
        "SMR20": {
    "nama": "Pulsa Smartfren 20.000",
    "hargaid": 20560,
    "harga":"Rp20.560",
    },
       "SMR25": {
    "nama": "Pulsa Smartfren 25.000",
    "hargaid": 25560,
    "harga":"Rp25.560",
    },
    "SMR30": {
    "nama": "Pulsa Smartfren 30.000",
    "hargaid": 30560,
    "harga":"Rp30.560",
    },
    "SMR40": {
    "nama": "Pulsa Smartfren 40.000",
    "hargaid": 40560,
    "harga":"Rp40.560",
    },
        "SMR50": {
    "nama": "Pulsa Smartfren 50.000",
    "hargaid": 50560,
    "harga":"Rp50.560",
    },
    "SMR60": {
    "nama": "Pulsa Smartfren 60.000",
    "hargaid": 60560,
    "harga":"Rp60.560",
    },
    "SMR70": {
    "nama": "Pulsa Smartfren 70.000",
    "hargaid": 70560,
    "harga":"Rp70.560",
    },
    "SMR80": {
    "nama": "Pulsa Smartfren 80.000",
    "hargaid": 80560,
    "harga":"Rp80.560",
    },
    "SMR90": {
    "nama": "Pulsa Smartfren 90.000",
    "hargaid": 90560,
    "harga":"Rp90.560",
    },
        "SMR100": {
    "nama": "Pulsa Smartfren 100.000",
    "hargaid": 100560,
    "harga":"Rp100.560",
    },            
},
};

module.exports = { list6 }

