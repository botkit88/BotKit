let list5 = {
  "indosat": {   
    "INDST5": {
    "nama": "Pulsa Indosat 5.000",
    "hargaid": 6500,
    "harga":"Rp6.500",
    },
        "INDST10": {
    "nama": "Pulsa Indosat 10.000 ",
    "hargaid": 11500,
    "harga":"Rp11.500",
    },
        "INDST15": {
    "nama": "Pulsa Indosat 15.000",
    "hargaid": 15780,
    "harga":"Rp15.780",
    },
        "INDST20": {
    "nama": "Pulsa Indosat 20.000",
    "hargaid": 20780,
    "harga":"Rp20.780",
    },
    "INDST30": {
    "nama": "Pulsa Indosat 30.000",
    "hargaid": 30780,
    "harga":"Rp30.780",
    },
    "INDST40": {
    "nama": "Pulsa Indosat 40.000",
    "hargaid": 40780,
    "harga":"Rp40.780",
    },
        "INDST50": {
    "nama": "Pulsa Indosat 50.000",
    "hargaid": 50780,
    "harga":"Rp50.780",
    },
    "INDST60": {
    "nama": "Pulsa Indosat 60.000",
    "hargaid": 60780,
    "harga":"Rp60.780",
    },
    "INDST70": {
    "nama": "Pulsa Indosat 70.000",
    "hargaid": 70780,
    "harga":"Rp70.780",
    },
    "INDST80": {
    "nama": "Pulsa Indosat 80.000",
    "hargaid": 80780,
    "harga":"Rp80.780",
    },
    "INDST90": {
    "nama": "Pulsa Indosat 90.000",
    "hargaid": 90780,
    "harga":"Rp90.780",
    },
        "INDST100": {
    "nama": "Pulsa Indosat 100.000",
    "hargaid": 100780,
    "harga":"Rp100.780",
    },            
},
};

module.exports = { list5 }