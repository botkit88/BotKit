const list46 = {
  "vcrtbulk": {   
    "VBT1": {
    "nama": "Voucher Telkomsel Data Bulk 4 GB / 30 Hari (Kode:1)",
    "hargaid": 43000, 
    "harga":"Rp43.000",
    },       
    "VBT2": {
    "nama": "Voucher Telkomsel Data Bulk 6 GB / 30 Hari (Kode:2)",
    "hargaid": 74000, 
    "harga":"Rp74.000",
    },   
    "VBT3": {
    "nama": "Voucher Telkomsel Data Bulk 9 GB / 30 Hari (Kode:3)",
    "hargaid": 95000, 
    "harga":"Rp95.000",
    },       
    "VBT4": {
    "nama": "Voucher Telkomsel Data Bulk 10 GB / 30 Hari (Kode:4)",
    "hargaid": 105000, 
    "harga":"Rp105.000",
    },   
},
};

module.exports = { list46 }

