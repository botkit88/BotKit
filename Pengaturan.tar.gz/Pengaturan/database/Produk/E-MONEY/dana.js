const list = {
  "dana": {
    "DANA1": {
    "nama": "DANA 1.000",
    "hargaid": 1280,
    "harga":"Rp1.280",
    },     
    "DANA2": {
    "nama": "DANA 2.000",
    "hargaid": 2280,
    "harga":"Rp2.280",
    },     
    "DANA3": {
    "nama": "DANA 3.000",
    "hargaid": 3280,
    "harga":"Rp3.280",
    },     
    "DANA4": {
    "nama": "DANA 4.000",
    "hargaid": 4280,
    "harga":"Rp4.280",
    },     
    "DANA5": {
    "nama": "DANA 5.000",
    "hargaid": 5350,
    "harga":"Rp5.350",
    },
        "DANA10": {
    "nama": "DANA 10.000 ",
    "hargaid": 10350,
    "harga":"Rp10.350",
    },
        "DANA15": {
    "nama": "DANA 15.000",
    "hargaid": 15350,
    "harga":"Rp15.350",
    },
        "DANA20": {
    "nama": "DANA 20.000",
    "hargaid": 20350,
    "harga":"Rp20.350",
    },
        "DANA25": {
    "nama": "DANA 25.000",
    "hargaid": 25.350,
    "harga":"Rp25.350",
    },
        "DANA30": {
    "nama": "DANA 30.000",
    "hargaid": 30350,
    "harga":"Rp30.350",
    },     
       "DANA35": {
    "nama": "DANA 35.000",
    "hargaid": 35350,
    "harga":"Rp35.350",
    },     
       "DANA40": {
    "nama": "DANA 40.000",
    "hargaid": 40350,
    "harga":"Rp40.350",
    },     
       "DANA45": {
    "nama": "DANA 45.000",
    "hargaid": 45350,
    "harga":"Rp45.350",
    },     
      "DANA50": {
    "nama": "DANA 50.000",
    "hargaid": 50350,
    "harga":"Rp50.350",
    },     
   "DANA55": {
    "nama": "DANA 55.000",
    "hargaid": 55350,
    "harga":"Rp55.350",
    },     
   "DANA60": {
    "nama": "DANA 60.000",
    "hargaid": 60350,
    "harga":"Rp60.350",
    },     
   "DANA65": {
    "nama": "DANA 65.000",
    "hargaid": 65350,
    "harga":"Rp65.350",
    },     
   "DANA70": {
    "nama": "DANA 70.000",
    "hargaid": 70350,
    "harga":"Rp70.350",
    },     
    "DANA75": {
    "nama": "DANA 75.000",
    "hargaid": 75350,
    "harga":"Rp75.350",
    },     
   "DANA80": {
    "nama": "DANA 80.000",
    "hargaid": 80350,
    "harga":"Rp80.350",
    },     
   "DANA85": {
    "nama": "DANA 85.000",
    "hargaid": 85350,
    "harga":"Rp85.350",
    },     
   "DANA90": {
    "nama": "DANA 90.000",
    "hargaid": 90350,
    "harga":"Rp90.350",
    },     
   "DANA95": {
    "nama": "DANA 95.000",
    "hargaid": 95350,
    "harga":"Rp95.350",
    },     
   "DANA100": {
    "nama": "DANA 100.000",
    "hargaid": 100350,
    "harga":"Rp100.350",
    },     
   "DANA200": {
    "nama": "DANA 200.000",
    "hargaid": 200350,
    "harga":"Rp200.350",
    },     
},
};

module.exports = { list }