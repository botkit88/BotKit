const list38 = {
  "freedomharian": {   
    "FRH1": {
    "nama": "Indosat Freedom Kuota Harian 7 GB / 7 Hari (Kode:1)",
    "hargaid": 28000, 
    "harga":"Rp28.000",
    },       
    "FRH2": {
    "nama":"Indosat Freedom Kuota Harian 14 GB / 14 Hari (Kode:2)",
    "hargaid": 50000,
    "harga":"Rp50.000",
    },
    "FRH3": {
    "nama":"Indosat Freedom Kuota Harian 28 GB / 28 Hari (Kode:3)",
    "hargaid": 85000,
    "harga":"Rp85.000",
    },
},
};

module.exports = { list38 }

