const list16 = {
  "unlimited": {   
    "UNL1": {
    "nama": "Smartfren Data Unlimited Harian 1 GB Berlaku 7 Hari (Kode:1)",
    "hargaid": 25300,
    "harga":"Rp25.300",
    },       
    "UNL500": {
    "nama":"Smartfren Data Unlimited Harian 500 MB Berlaku 28 Hari (Kode:500)",
    "hargaid": 64500,
    "harga":"Rp64.500",
    },
    "UNL700": {
    "nama":"Smartfren Data Unlimited Harian 700 MB Berlaku 28 Hari (Kode:700)",
    "hargaid": 66300,
    "harga":"Rp66.300",
    },
},
};

module.exports = { list16 }

