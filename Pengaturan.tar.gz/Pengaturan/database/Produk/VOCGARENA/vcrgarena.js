const list53 = {
  "vcrgarena": {   
    "VGARENA1": {
    "nama": "Voucher Garena 33 Shell (Kode:1)",
    "hargaid": 43000, 
    "harga":"Rp43.000",
    },       
    "VGARENA2": {
    "nama": "Voucher Garena 66 Shell (Kode:2)",
    "hargaid": 74000, 
    "harga":"Rp74.000",
    },   
    "VGARENA3": {
    "nama": "Voucher Garena 165 Shell (Kode:4)",
    "hargaid": 95000, 
    "harga":"Rp95.000",
    },   
    "VGARENA4": {
    "nama": "Voucher Garena 330 Shell (Kode:5)",
    "hargaid": 95000, 
    "harga":"Rp95.000",
    },      
},
};

module.exports = { list53 }