const list48 = {
  "vcrindstj": {   
    "VINDSTJ1": {
    "nama": "Voucher Indosat Jabodetabek Freedom Internet Harian 2.5 GB / 5 Hari (Kode:1)",
    "hargaid": 43000, 
    "harga":"Rp43.000",
    },       
    "VINDSTJ2": {
    "nama": "Voucher Indosat Jabodetabek Freedom Internet 3 GB / 30 Hari (Kode:2)",
    "hargaid": 74000, 
    "harga":"Rp74.000",
    },   
},
};

module.exports = { list48 }