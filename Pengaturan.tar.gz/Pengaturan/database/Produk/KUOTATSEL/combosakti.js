const list33 = {
  "combosakti": {   
    "CS1": {
    "nama": "Telkomsel Data Combo Sakti 1,5 GB (Kode:1)",
    "hargaid": 22000, 
    "harga":"Rp22.000",
    },       
    "CS2": {
    "nama":"Telkomsel Data Combo Sakti 2,5 GB (Kode:2)",
    "hargaid": 33000,
    "harga":"Rp33.000",
    },
    "CS3": {
    "nama":"Telkomsel Data Combo Sakti 3 GB (Kode:3)",
    "hargaid": 38000,
    "harga":"Rp38.000",
    },
    "CS4": {
    "nama":"Telkomsel Data Combo Sakti 5 GB (Kode:4)",
    "hargaid": 50000,
    "harga":"Rp50.000",
    },
    "CS5": {
    "nama":"Telkomsel Data Combo Sakti 10 GB (Kode:5)",
    "hargaid": 65000,
    "harga":"Rp65.000",
    },
    "CS6": {
    "nama":"Telkomsel Data Combo Sakti 11 GB (Kode:6)",
    "hargaid": 68000,
    "harga":"Rp68.000",
    },
    "CS7": {
    "nama":"Telkomsel Data Combo Sakti 13 GB (Kode:7)",
    "hargaid": 77000,
    "harga":"Rp77.000",
    },
    "CS8": {
    "nama":"Telkomsel Data Combo Sakti 15 GB (Kode:8)",
    "hargaid": 90000,
    "harga":"Rp90.000",
    },
    "CS9": {
    "nama":"Telkomsel Data Combo Sakti 17 GB (Kode:9)",
    "hargaid": 97000, 
    "harga":"Rp97.000",
    },
    "CS10": {
    "nama":"Telkomsel Data Combo Sakti 18 GB (Kode:10)",
    "hargaid": 105000, 
    "harga":"Rp105.000",
    },
    "CS11": {
    "nama":"Telkomsel Data Combo Sakti 19 GB (Kode:11)",
    "hargaid": 110000, 
    "harga":"Rp110.000",
    },
    "CS12": {
    "nama":"Telkomsel Data Combo Sakti 20 GB (Kode:12)",
    "hargaid": 112000, 
    "harga":"Rp112.000",
    },
},
};

module.exports = { list33 }

