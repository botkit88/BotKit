const list31 = {
  "flashtsel": {   
    "FT1": {
    "nama": "Telkomsel Data Flash 5.000 (Kode:1)",
    "hargaid": 5500, 
    "harga":"Rp5.500",
    },       
    "FT2": {
    "nama":"Telkomsel Data Flash 10.000 (Kode:2)",
    "hargaid": 10500,
    "harga":"Rp10.500",
    },
    "FT3": {
    "nama":"Telkomsel Data Flash 1 GB / 30 Hari (Kode:3)",
    "hargaid": 16000,
    "harga":"Rp16.000",
    },
    "FT4": {
    "nama":"Telkomsel Data Flash 2 GB / 30 Hari (Kode:4)",
    "hargaid": 200000,
    "harga":"Rp20.000",
    },
    "FT5": {
    "nama":"Telkomsel Data Flash 4 GB / 30 Hari (Kode:5)",
    "hargaid": 45000,
    "harga":"Rp45.000",
    },
    "FT6": {
    "nama":"Telkomsel Data Flash 4 GB / 30 Hari (Kode:6)",
    "hargaid": 48000,
    "harga":"Rp48.000",
    },
    "FT7": {
    "nama":"Telkomsel Data Flash 8 GB / 30 Hari (Kode:7)",
    "hargaid": 65000,
    "harga":"Rp65.000",
    },
},
};

module.exports = { list31 }

