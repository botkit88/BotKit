// HARAP DI ENC, KECOLONGAN APIKEY TANGGUNG SENDIRI JAN NGOMEL KE OWNER!!!!
// API DIGIFLAZZ
const digiuser = 'gewukuDlk0Eo'
const digiapi = 'dev-6af93ea0-506c-11ee-8c24-2567ca073638'
const nomorKu = '6289660378730@s.whatsapp.net'
// Api Vipress

module.exports = {
    digiuser,
    digiapi,
    nomorKu
}