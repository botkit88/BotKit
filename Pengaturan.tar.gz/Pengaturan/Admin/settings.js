const chalk = require("chalk")
const fs = require("fs")

//______________________[ PERLENGKAPAN ]_______________________//
global.owner = '6289660378730' //Ganti Jadi No Lu
global.ownerNomor = '6289660378730'
global.botname = 'KAORI BLESSING' //Ganti Jadi Nama Bot Lu
global.namabot = 'KAORI BLESSING' 
global.ownername = 'KIT88' 
global.ownerName = '𝐊𝐫𝐢𝐬 𝐇𝐨𝐬𝐭𝐢𝐧𝐠' //Ganti Jadi Nama Lu
global.footer = 'KrisBotz'
global.packname = `BotWa` 
global.struk = `𝗞𝗥𝗜𝗦` 
global.toko = `©CICANG GAMING`
global.youtube = `@kit.88`






//______________________[ THUMBNAIL ]_______________________//
global.qrisdana = { url: 'https://telegra.ph/file/6b280356b7e7d6c06fecf.jpg'}
global.qrisgopay = { url: 'https://telegra.ph/file/4173a2840cb92747a50e1.jpg'}
global.krismenu = { url: 'https://telegra.ph/file/e79f735a244151fe186e7.jpg' } //Gak Usah Di Ganti
global.qrisdonate = { url: 'https://telegra.ph/file/d2548c6f84f14b5faf9d4.jpg' } //Gak Usah Di Ganti
global.antilink = false

global.mess = {
    wait: 'Proses Tunggu',
    succes: 'Selesai',
    admin: 'Khusus Admin Grup',
    botAdmin: 'Bot Nya Aja Gak Admin Duh',
    owner: 'Khusus Owner',
    group: 'Fitur Untuk Grup Anjay',
    private: 'Fitur Cuma Bisa Di Private Chat',
    bot: 'Bot Number User Special Features!!!',
    error: 'Anjay Eror...',    
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})